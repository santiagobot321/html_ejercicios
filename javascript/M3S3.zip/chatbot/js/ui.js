function renderizarHistorial() {
    
}